'use strict';

// Read-only checks. No server modules, environment values, subprocesses or network.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const TARGET_ROOT = '/opt/beforeword-mcp/releases/bb079a16c94ca6b6b76e';
const MAX_FILE_BYTES = 1024 * 1024;
const CORE_SHA256 = 'a4d09af033be6f272b1c05a09fdb29fc412ebf59433466518c2cc2409e818249';
const CHECKS = Object.freeze([
  ['lib/core.en.txt', CORE_SHA256, 'core_sha256'],
  ['lib/core-provenance.json', '48fc40e6782bf0d6f1ca9f249f71ed9817e3b0ce852969e177382e1c0c1bac98', 'provenance_sha256'],
  ['main.mjs', '7064162960db8a21d3a35e5f31bb5a3351f0a0508a7fdfe8b7367d3de5ad95c3', 'main_guard'],
  ['server.mjs', '10e69dae085195e9f9598a2e4e8156a5bf875de0e8f52c07d77c5cb991070186', 'server_guard'],
  ['http.mjs', '5f6f896e72f592c5ffd7218cd4020382561937d7a6a5590280bdca4fe3500f1d', 'http_guard'],
  ['package.json', '0ff034ed67be82918d58421a89f5ccd523e66f16d655d48d6ba342a5586c4036', 'package_guard'],
]);

function readRegular(root, relative) {
  const filename = path.join(root, relative);
  let parent = root;
  for (const component of relative.split('/').slice(0, -1)) {
    parent = path.join(parent, component);
    if (!fs.lstatSync(parent).isDirectory()) throw new Error('refused');
  }
  if (!fs.constants.O_NOFOLLOW) throw new Error('refused');
  const fd = fs.openSync(filename, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | (fs.constants.O_NONBLOCK || 0));
  try {
    const before = fs.fstatSync(fd, { bigint: true });
    if (!before.isFile() || before.nlink !== 1n || before.size > BigInt(MAX_FILE_BYTES)) throw new Error('refused');
    const raw = Buffer.alloc(Number(before.size));
    let offset = 0;
    while (offset < raw.length) {
      const count = fs.readSync(fd, raw, offset, raw.length - offset, offset);
      if (!count) throw new Error('refused');
      offset += count;
    }
    const extra = Buffer.alloc(1);
    if (fs.readSync(fd, extra, 0, 1, offset) !== 0) throw new Error('refused');
    const after = fs.fstatSync(fd, { bigint: true });
    for (const key of ['dev', 'ino', 'size', 'mtimeNs', 'ctimeNs', 'mode', 'uid', 'gid', 'nlink']) {
      if (before[key] !== after[key]) throw new Error('refused');
    }
    return raw;
  } finally {
    fs.closeSync(fd);
  }
}

function verify(root = TARGET_ROOT) {
  let check = 'root';
  try {
    root = path.resolve(root);
    if (fs.realpathSync(root) !== root || !fs.lstatSync(root).isDirectory()) throw new Error('refused');
    let provenance;
    for (const [relative, expected, code] of CHECKS) {
      check = code;
      const raw = readRegular(root, relative);
      if (crypto.createHash('sha256').update(raw).digest('hex') !== expected) throw new Error('refused');
      if (relative === 'lib/core-provenance.json') provenance = JSON.parse(raw.toString('utf8'));
    }
    check = 'provenance_fields';
    if (!provenance || Object.keys(provenance).sort().join(',') !== 'sha256,source,version' ||
        provenance.source !== 'assets/core.en.txt' || provenance.sha256 !== CORE_SHA256 ||
        provenance.version !== '1.4.2') throw new Error('refused');
    return { status: 'ok', checks: 7, instruction_version: '1.4.2', implementation_version: '1.4.1' };
  } catch {
    return { status: 'failed', check };
  }
}

module.exports = Object.freeze({ verify });
if (require.main === module) {
  const result = process.argv.length > 3 ? { status: 'failed', check: 'arguments' } : verify(process.argv[2]);
  process.stdout.write(JSON.stringify(result) + '\n');
  process.exitCode = result.status === 'ok' ? 0 : 1;
}
