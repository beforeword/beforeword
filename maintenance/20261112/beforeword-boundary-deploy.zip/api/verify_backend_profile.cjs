'use strict';
// Local module-contract check only. Does not import app/config or contact APIs.
const path = require('node:path');
const crypto = require('node:crypto');
const EXPECTED_CORE = 'a4d09af033be6f272b1c05a09fdb29fc412ebf59433466518c2cc2409e818249';
const root = path.resolve(process.argv[2] || '/home/befohuyc/beforeword-api');
const fail = () => { throw new Error('PROFILE_CHECK_FAILED'); };
try {
  const modes = require(path.join(root, 'server/answer-modes.cjs'));
  const answer = require(path.join(root, 'server/answer.cjs'));
  const core = require(path.join(root, 'extension/analysis-core.js'));
  const instruction = globalThis.BeforewordInstructions;
  if (!instruction || instruction.version !== '1.4.2' || typeof instruction.core !== 'string') fail();
  const digest = crypto.createHash('sha256').update(instruction.core, 'utf8').digest('hex');
  if (digest !== EXPECTED_CORE) fail();
  const baselineHashes = {};
  for (const language of ['ru', 'en']) {
    const profile = modes.policyFor({mode: 'text', language});
    const baseline = modes.policyFor({mode: 'baseline', language});
    if (profile.profileVersion !== '1.4.2' || profile.profileHash !== EXPECTED_CORE || profile.content !== profile.common + '\n\n' + instruction.core) fail();
    if (baseline.profileVersion !== null || baseline.profileHash !== null || baseline.content !== profile.common) fail();
    const supplied = {text: 'Local profile contract check', language, history: [], mode: 'text'};
    const configuration = {model: 'local-check', apiKey: 'unused-local-placeholder'};
    if (answer.buildAnswerRequest(supplied, configuration).body.messages[0].content !== profile.content) fail();
    delete supplied.mode;
    if (!answer.buildAnswerRequest(supplied, configuration).body.messages[0].content.startsWith(instruction.core)) fail();
    if (!core.buildRequest({text: supplied.text, language}).system.startsWith(instruction.core)) fail();
    baselineHashes[language] = baseline.commonPolicyHash;
  }
  console.log(JSON.stringify({status: 'local_profile_matches', instructionVersion: instruction.version, coreSha256: digest, baselineCommonPolicyHashes: baselineHashes}));
} catch (_) {
  console.log(JSON.stringify({status: 'local_profile_mismatch'}));
  process.exitCode = 1;
}
