'use strict';
const crypto = require('node:crypto');
require('../extension/instructions.js');
const instruction = globalThis.BeforewordInstructions;
if (!instruction || instruction.version !== '1.4.2' || typeof instruction.core !== 'string') {
  throw new Error('BEFOREWORD_CORE_PROFILE_UNAVAILABLE');
}
const VERSION = instruction.version;
const PROFILE = instruction.core;
const HASH = crypto.createHash('sha256').update(PROFILE, 'utf8').digest('hex');
if (HASH !== 'a4d09af033be6f272b1c05a09fdb29fc412ebf59433466518c2cc2409e818249') {
  throw new Error('BEFOREWORD_CORE_PROFILE_HASH_MISMATCH');
}
module.exports = Object.freeze({ VERSION, PROFILE, HASH });
