# beforeword 1.3.6 — portable research candidate

This archive contains six English/Russian instruction editions, two full skill
wrappers, four evaluation datasets, these two README files and MANIFEST.json.
It is a research candidate, not an installed plugin or a tested model result.
The full skills preserve their corresponding core instruction exactly; the
medium and compact editions are separately edited versions.

## Contents and evidence

- core.en.txt / core.ru.txt: full instructions.
- medium.en.txt / medium.ru.txt: editions below 5,000 characters.
- compact.en.txt / compact.ru.txt: editions below 1,500 characters.
- skills/en/SKILL.md / skills/ru/SKILL.md: full skill source documents.
- test-cases.jsonl: 14 authored cases and rubrics, seven per language.
- samples.jsonl / samples.en.jsonl / samples.ru.jsonl: runnable prompt data.
- MANIFEST.json: SHA-256 hashes of every other archive member.

Case u-13 includes an explicitly synthetic device record in the prompt. It is
a positive control for using supplied premises within a fictional scenario;
it contains no real patient data and does not verify a physical event.

The manifest identifies these exact bytes. It does not claim that they equal a
particular Git commit, establish model adherence, or certify medical behavior.
No provider runner or source checker is included in this archive.

## Running or checking

Running the prompts and checking repository consistency require a checkout of
the [beforeword repository](https://github.com/beforeword/beforeword), including its evaluation tools and
release-contract files. Follow the repository's current documentation:

- [Cross-provider runner and usage](https://github.com/beforeword/beforeword/blob/main/evaluations/multi-provider/README.md)
- [Candidate documentation](https://github.com/beforeword/beforeword/blob/main/evaluations/instruction-1.3.6/README.md)
- [Candidate source checker](https://github.com/beforeword/beforeword/blob/main/evaluations/instruction-1.3.6/verify_candidate.py)

These are repository links, not files inside this ZIP. The main branch can
change; compare the archive's manifest hashes with the checkout before treating
them as the same candidate. Dry runs do not call models. Real provider calls
require explicit execution and may incur provider charges. Compare baseline
and instructed conditions with the language-matched dataset; no scores or
model responses are included here.

## Rebuilding and limits

The repository's build_candidate_bundle.py builds this archive from the twelve
source files listed above and dedicated archive README text. Fixed ZIP metadata
and uncompressed entries make the output deterministic without external tools.
The two repository README files are not copied into the archive.

Publication does not install these texts in an application or promote 1.3.6 to
the selected release. Follow the current repository release contract for that
status. Static checks establish only their stated structural checks.
