# beforeword · 1.3.0

RU

Язык инструкции в этом архиве: RU. Установи одну языковую редакцию; одинаковое имя не предназначено для двух параллельных установок. Язык ответа можно задать в запросе.

Навык сохраняет исходный текст, отделяет добавленное прочтением и применяет ту же границу к собственному ответу. Он вызывается для задачи и не меняет все разговоры аккаунта. Для более широкого действия задавай область явно: «Применяй beforeword в этом разговоре». Для разового разбора: «Примени beforeword к фразе „Я понимаю“». Просьба «Отключи режим beforeword для следующих ответов» меняет запрос; доступность установленного навыка регулируется настройками приложения.

После подключения начни новый разговор и выполни пример. Сохрани ввод и ответ: наличие названия beforeword само по себе не показывает качество разбора. При проблеме запиши приложение, его версию, способ установки и полный текст ошибки. Пакет содержит только инструкции и файлы настройки, без сервера, ключей, фоновых действий и телеметрии.

EN

Instruction language in this archive: RU. Install one language edition; the shared name is not intended for two parallel installations. Request any response language explicitly.

The skill preserves the supplied text, separates added readings, and applies the same boundary to its own response. It is invoked for a task and does not change every conversation in an account. To request broader scope, say “Apply beforeword in this conversation.” For one task: “Apply beforeword to the phrase ‘I understand.’” The request “Turn off beforeword mode for subsequent replies” changes the requested scope; application settings control whether the installed skill remains available.

After setup, start a new conversation and try the example. Keep the input and output: the name beforeword appearing in a response does not establish the quality of its analysis. For troubleshooting, record the app, version, installation method, and complete error. The package contains only instructions and configuration files, with no server, keys, background actions, or telemetry.

## ChatGPT desktop / Codex: локальный каталог / local marketplace

RU

Это ZIP локального проекта, а не ZIP для загрузки в публичный каталог. Распакуй всё содержимое в отдельную рабочую папку. В её корне должны находиться `.agents/plugins/marketplace.json` и `plugins/beforeword/plugin.json`; сохраняй скрытую папку `.agents`. `source.path` в каталоге задан относительно этой рабочей папки.

Открой эту папку как локальный проект в поддерживающей локальные каталоги среде ChatGPT desktop / Codex. Обнови или повторно открой список Plugins; найди beforeword в источнике `beforeword-local` и установи/включи его доступными в приложении элементами управления. Если источник не появился, используй приведённую ниже процедуру для своего desktop/CLI, а не загрузку ZIP в обычное сообщение. Web/mobile этот локальный путь установки не предоставляет; для них используй текстовую инструкцию в настройках или чате.

Для обновления замени `plugins/beforeword/` новой редакцией и обнови локальный источник средствами среды. Для отключения используй переключатель плагина. Удаление исходной папки не означает удаления установленной копии: приложение может хранить её в своём кэше. Управляй установленной копией через Plugins. Этот архив не изменяет личный каталог или конфигурацию пользователя автоматически.

EN

This ZIP is a local project, not a public-directory upload. Extract its entire contents into a separate working folder. Keep `.agents/plugins/marketplace.json` and `plugins/beforeword/plugin.json` at the shown locations, including the hidden `.agents` folder. The catalog's `source.path` is relative to that working folder.

Open the folder as a local project in a ChatGPT desktop / Codex environment supporting local marketplaces. Refresh or reopen Plugins, find beforeword under `beforeword-local`, and install/enable it using the available controls. If the source is missing, follow the linked procedure for your desktop/CLI instead of uploading the ZIP in an ordinary message. Web/mobile does not provide this local installation route; use the text instructions in settings or a chat there.

To update, replace `plugins/beforeword/` with the new edition and refresh the local source through the host. Use the plugin's toggle to disable it. Removing the source folder does not remove an installed cached copy; manage that copy through Plugins. This archive does not automatically modify your personal marketplace or configuration.

Package and local-marketplace documentation: https://developers.openai.com/plugins/build/plugins
