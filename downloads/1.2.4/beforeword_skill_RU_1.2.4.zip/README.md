# beforeword · 1.2.4

RU

Язык инструкции в этом архиве: RU. Установи одну языковую редакцию; одинаковое имя не предназначено для двух параллельных установок. Язык ответа можно задать в запросе.

Навык сохраняет исходный текст, отделяет добавленное прочтением и применяет ту же границу к собственному ответу. Он вызывается для задачи и не меняет все разговоры аккаунта. Для более широкого действия задавай область явно: «Применяй beforeword в этом разговоре». Для разового разбора: «Примени beforeword к фразе „Я понимаю“». Просьба «Отключи режим beforeword для следующих ответов» меняет запрос; доступность установленного навыка регулируется настройками приложения.

После подключения начни новый разговор и выполни пример. Сохрани ввод и ответ: наличие названия beforeword само по себе не показывает качество разбора. При проблеме запиши приложение, его версию, способ установки и полный текст ошибки. Пакет содержит только инструкции и файлы настройки, без сервера, ключей, фоновых действий и телеметрии.

EN

Instruction language in this archive: RU. Install one language edition; the shared name is not intended for two parallel installations. Request any response language explicitly.

The skill preserves the supplied text, separates added readings, and applies the same boundary to its own response. It is invoked for a task and does not change every conversation in an account. To request broader scope, say “Apply beforeword in this conversation.” For one task: “Apply beforeword to the phrase ‘I understand.’” The request “Turn off beforeword mode for subsequent replies” changes the requested scope; application settings control whether the installed skill remains available.

After setup, start a new conversation and try the example. Keep the input and output: the name beforeword appearing in a response does not establish the quality of its analysis. For troubleshooting, record the app, version, installation method, and complete error. The package contains only instructions and configuration files, with no server, keys, background actions, or telemetry.

## Gemini / Mistral Vibe Work

RU

Gemini: если раздел доступен, открой Settings → Skills → Upload, выбери этот ZIP или извлечённый `SKILL.md`, просмотри поля и нажми Create. В архиве `SKILL.md` находится в корне. Для обновления в веб-версии открой Settings → Skills, выбери beforeword, затем More → Replace skill, загрузи новый пакет и сохрани. Для ручного изменения отредактируй Description и Instructions. Включение и удаление навыка выполняются на странице Skills; сообщение в разговоре не заменяет управление установленным навыком.

Mistral Vibe Work: Context → Skills → New Skill. Перенеси `name` из верхнего блока SKILL.md в Title, `description` — в Description, а текст после закрывающего `---` — в поле SKILL.md. Сохрани и включи навык. Этот путь использует форму создания, а не обещает ZIP-импорт. Начни новую задачу и попроси применить beforeword; для отключения используй переключатель на странице Skills. Для обновления открой beforeword в Context → Skills, замени Description и текст SKILL.md, сохрани и начни новый чат; действующие чаты сохраняют прежнюю инструкцию.

EN

Gemini: where Skills is available, open Settings → Skills → Upload, select this ZIP or the extracted `SKILL.md`, review the fields, and choose Create. `SKILL.md` is at the archive root. To update on the web, open Settings → Skills, select beforeword, choose More → Replace skill, upload the new package and save. For manual changes, edit Description and Instructions. Enablement and deletion are managed on the Skills page; a conversational request does not replace installed-skill controls.

Mistral Vibe Work: Context → Skills → New Skill. Transfer `name` from the SKILL.md header to Title, `description` to Description, and the text after the closing `---` to the SKILL.md field. Save and enable the skill. This uses the creation form and does not promise ZIP import. Start a new task and request beforeword; use the Skills-page toggle to disable it. To update, open beforeword under Context → Skills, replace Description and SKILL.md, save and start a new chat; active chats retain the previous instructions.

Gemini: https://support.google.com/gemini/answer/17094296?hl=en
Mistral Vibe Work: https://docs.mistral.ai/vibe/work/skills
