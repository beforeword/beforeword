#!/usr/bin/env python3
"""Build the standalone beforeword guide and text exports without network access."""
from __future__ import annotations
import argparse
import base64
import hashlib
import html
import io
import json
import re
from pathlib import Path
import stat
import zipfile
from package_plugins import build_bundles, skill_text
from render_report import parse_report
from release_contract import VERSION, DATE, require_selected

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_bytes().decode('utf-8')

def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def evaluation_html(source, language):
    title, body = parse_report(source)
    body = body.replace('href="/model/reports/', 'href="https://beforeword.xyz/model/reports/')
    body = body.replace('report-section-', 'evaluation-'+language+'-section-')
    body = body.replace('<h2', '<h4').replace('</h2>', '</h4>')
    return '<h3>'+html.escape(title)+'</h3>\n'+body

def source_bundle():
    files = {}
    for folder in ('assets', 'brand', 'references', 'scripts', 'docs', '.github', 'catalog', 'plugins', 'integrations'):
        for path in sorted((ROOT / folder).rglob('*')):
            if any(part in ('node_modules', 'build', 'dist', '__pycache__', '.git') for part in path.relative_to(ROOT).parts):
                continue
            if path.is_symlink():
                raise ValueError('Source bundle refuses symlinks: ' + str(path.relative_to(ROOT)))
            if path.is_file() and (path.suffix in ('.py', '.cjs', '.mjs', '.md', '.txt', '.json', '.jsonl', '.html', '.svg', '.css', '.js', '.yml', '.yaml', '.woff', '.woff2', '.png') or path.name in ('LICENSE', '.gitignore')) and path.name != 'release.json' and not path.is_relative_to(ROOT / 'catalog' / 'packages'):
                files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    files['SKILL.md'] = (ROOT / 'SKILL.md').read_bytes()
    for name in ('README.md', 'README.ru.md', 'CHANGELOG.md', 'LICENSE', 'LICENSE.txt', 'LICENSE.md', '.gitignore'):
        path = ROOT / name
        if path.is_file():
            files[name] = path.read_bytes()
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path, content in sorted(files.items()):
            info = zipfile.ZipInfo('beforeword/' + path, (*map(int, DATE.split('-')), 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, content)
    raw = out.getvalue()
    return {'name': 'beforeword_toolkit.zip', 'data': base64.b64encode(raw).decode(),
            'sha256': hashlib.sha256(raw).hexdigest(), 'files': sorted(files)}

def fallback(data):
    esc = html.escape
    sections = ['<div class="static-fallback"><p>JavaScript не выполняется. Ниже — все инструкции для ручного копирования. / JavaScript is unavailable. All instructions are below for manual copying.</p>']
    for lang in ('ru', 'en'):
        sections.append('<section lang="'+lang+'"><h2>'+('Инструкции · RU' if lang == 'ru' else 'Instructions · EN')+'</h2>')
        sections.append('<p>'+('Выбери один способ: настройка ответов, навык или API. Не требуется устанавливать всё. Полная инструкция раскрывает больше различий; краткая предназначена для ограниченного поля.' if lang == 'ru' else 'Choose one route: response settings, a skill, or API. These are alternatives. The full instruction covers more distinctions; the compact text is intended for limited fields.')+'</p>')
        sections.append('<h3>'+('Краткая инструкция' if lang == 'ru' else 'Compact instructions')+'</h3><pre>'+esc(data['compact'][lang])+'</pre>')
        sections.append('<h3>'+('Инструкция до 5 000 знаков' if lang == 'ru' else 'Instructions up to 5,000 characters')+'</h3><pre>'+esc(data['medium'][lang])+'</pre>')
        sections.append('<details><summary>'+('Полная инструкция' if lang == 'ru' else 'Full instructions')+'</summary><p>'+esc(data['scope'][lang].strip())+'</p><pre>'+esc(data['core'][lang])+'</pre></details>')
        for c in data['connectors']:
            v = c[lang]
            sections.append('<details><summary>'+esc(c['name'])+'</summary><p>'+esc(v['route'])+'</p><ol>'+''.join('<li>'+esc(step)+'</li>' for step in v['steps'])+'</ol><p>'+esc(v['scope'])+'</p><p>'+esc(v['limit'])+'</p></details>')
        report_body = data['evaluationHtmlRu' if lang == 'ru' else 'evaluationHtml'].replace('evaluation-'+lang+'-section-', 'fallback-evaluation-'+lang+'-section-')
        sections.append('<details><summary>'+('Методика и выполненные проверки' if lang == 'ru' else 'Method and completed checks')+'</summary><article class="evaluation-report">'+report_body+'</article><p class="small">'+('Методика доступна без интернета. Для открытия исходных файлов по ссылкам нужно подключение.' if lang == 'ru' else 'The method is available offline. Opening the linked source files requires an internet connection.')+'</p></details>')
        sections.append('<p>'+('Для загрузки пакетов навыков и работы с API открой этот HTML в браузере с JavaScript. Текст выше можно выделить и скопировать из предварительного просмотра.' if lang == 'ru' else 'For skill package downloads and the API builder, open this HTML in a browser with JavaScript. The text above can be selected and copied from a file preview.')+'</p></section>')
    sections.append('</div>')
    return '\n'.join(sections)

def build(output):
    require_selected(ROOT)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    data = {'version':VERSION, 'date':DATE,
            'core':{lang:read(f'assets/core.{lang}.txt') for lang in ('ru','en')},
            'compact':{lang:read(f'assets/compact.{lang}.txt') for lang in ('ru','en')},
            'medium':{lang:read(f'assets/medium.{lang}.txt') for lang in ('ru','en')},
            'scope':{lang:read(f'assets/scope.{lang}.txt').rstrip('\n')+'\n\n' for lang in ('ru','en')},
            'connectors':json.loads(read('references/connectors.json')),
            'api':json.loads(read('references/api.json'))['providers'],
            'skill':{lang:skill_text(lang) for lang in ('ru','en')},
            'eval':read('references/eval-cases.jsonl'),
            'evaluation':read('references/evaluation.md'),
            'evaluationRu':read('references/evaluation.ru.md'),
            'bundles':{}}
    data['evaluationHtml'] = evaluation_html(data['evaluation'], 'en')
    data['evaluationHtmlRu'] = evaluation_html(data['evaluationRu'], 'ru')
    for lang in ('ru','en'):
        data['bundles'][lang] = {}
        for key, record in build_bundles(lang, version=VERSION).items():
            data['bundles'][lang][key] = {k:v for k,v in record.items() if k not in ('bytes','file_contents')}
            data['bundles'][lang][key]['data'] = base64.b64encode(record['bytes']).decode()
    sources = {}
    for c in data['connectors']:
        for s in c['sources']: sources[s['url']] = s
    for provider in data['api'].values():
        for url in provider['sources']: sources.setdefault(url, {'title':url, 'url':url})
    data['sources'] = list(sources.values())
    data['developer'] = source_bundle()
    serialized = json.dumps(data, ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    brand_svg = read('assets/beforeword.svg')
    brand_svg = re.sub(r'\s(?:width|height|role|aria-label)="[^"]*"', '', brand_svg)
    brand_svg = re.sub(r' style="color:#[a-fA-F0-9]+"', '', brand_svg)
    brand_svg = brand_svg.replace('<svg ', '<svg style="display:block;width:min(220px,42vw);height:auto" aria-hidden="true" focusable="false" ', 1)
    result = read('assets/guide.template.html').replace('__BRAND_SVG__', brand_svg).replace('__DATA__', serialized).replace('__STATIC_FALLBACK__', fallback(data)).replace('__EVALUATION_RU__', data['evaluationHtmlRu']).replace('__EVALUATION_EN__', data['evaluationHtml'])
    if any(token in result for token in ('__BRAND_SVG__', '__DATA__', '__STATIC_FALLBACK__', '__EVALUATION_RU__', '__EVALUATION_EN__')):
        raise ValueError('unresolved template placeholder')
    path = output / 'beforeword_AI.html'
    path.write_text(result, encoding='utf-8')
    for lang in ('ru','en'):
        (output / f'beforeword_compact_{lang.upper()}.txt').write_text(data['compact'][lang], encoding='utf-8')
        (output / f'beforeword_5000_{lang.upper()}.txt').write_text(data['medium'][lang], encoding='utf-8')
        (output / f'beforeword_core_{lang.upper()}.txt').write_bytes(data['core'][lang].encode('utf-8'))
    report = json.loads(read('references/evaluation-results.json'))
    followup = json.loads(read('references/validation-2026-10-02.json'))
    previous = json.loads(read('references/validation-1.2.4.json'))
    smoke = json.loads(read('references/development-smoke-1.3.0.json'))
    previous_smoke = json.loads(read('references/development-smoke-1.3.1.json'))
    comparison = json.loads(read('references/comparison-1.3.3.json'))
    selected_review_path = 'references/development-review-1.4.1.json'
    selected_review_text = read(selected_review_path)
    selected_review = json.loads(selected_review_text)
    for lang in ('en', 'ru'):
        if selected_review['selected_editions']['core'][lang]['sha256'] != sha(data['core'][lang]):
            raise ValueError('Current development record does not match selected core: ' + lang)
    current_review_path = 'references/development-review-1.3.5.json'
    current_review_text = read(current_review_path)
    current_review = json.loads(current_review_text)  # A malformed review must not enter a release.
    historical_review_path = 'references/development-review-1.3.4.json'
    historical_review_text = read(historical_review_path)
    json.loads(historical_review_text)
    manifest = {'version':VERSION, 'date_utc':DATE, 'families':[c['id'] for c in data['connectors']],
      'core_sha256':{k:sha(v) for k,v in data['core'].items()},
      'compact_characters':{k:len(v) for k,v in data['compact'].items()},
      'medium_characters':{k:len(v) for k,v in data['medium'].items()},
      'medium_sha256':{k:sha(v) for k,v in data['medium'].items()},
      'native_bundles':{lang:{key:{k:v for k,v in record.items() if k!='data'} for key,record in bundles.items()} for lang,bundles in data['bundles'].items()},
      'developer_bundle':{k:v for k,v in data['developer'].items() if k!='data'},
      'guide_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
      'evaluation_scope':'The build runs no model. Each record below retains its instruction version, edition and adapter. Historical findings do not establish behavior of the current selected bytes; the selected instruction review is recorded separately with exact instruction hashes.',
      'runtime_validation':'not-run-by-build', 'evaluation':report['method'], 'evaluation_case_count':len(data['eval'].strip().splitlines()),
      'evaluation_runs':[
        {'report':selected_review_path, 'instruction_version':'1.4.1', 'historical':VERSION != '1.4.1',
         'scope':'Bounded development and separate comparison; AI-agent content judgments and deterministic checks are distinct. Retained failures and scope findings are in the record; no general adherence or native-installation claim.',
         'development_outputs':sum(run['observed_answers'] for run in selected_review['runs']),
         'reader_outputs':selected_review['reader_adapter']['provider_calls'],
         'comparison_outputs':selected_review['comparison'].get('provider_calls', 0),
         'report_sha256':sha(selected_review_text)},
        {'report':current_review_path, 'instruction_version':'1.3.5', 'historical':VERSION != '1.3.5',
         'scope':'Development cases for instruction 1.3.5 plus its bounded Hugging Face Playground check; no result transfers to a different instruction or adapter.',
         'selected_development_outputs':len(current_review['results']),
         'hugging_face_playground_outputs':len(current_review['HuggingFacePlayground12']['results']),
         'report_sha256':sha(current_review_text)},
        {'report':historical_review_path, 'instruction_version':'1.3.4', 'historical':True,
         'scope':'Bounded qualitative full-core development review; consult the record for exact inputs, outputs and limitations.',
         'report_sha256':sha(historical_review_text)},
        {'report':'references/comparison-1.3.3.json', 'instruction_version':'1.3.3', 'historical':True, 'selected_arm':comparison['selection']['selected_arm'], 'decision':comparison['selection']['decision'], 'answers':len(comparison['responses']), 'method':comparison['study']},
        {'report':'references/development-smoke-1.3.1.json', 'instruction_version':'1.3.1', 'historical':True, 'answers':previous_smoke['method']['responses'], 'method':previous_smoke['method']},
        {'report':'references/development-smoke-1.3.0.json', 'instruction_version':'1.3.0', 'answers':smoke['method']['responses'], 'method':smoke['method']},
        {'report':'references/evaluation-results.json', 'condition':'authored fixtures and targeted follow-up', 'method':report['method']},
        {'report':'references/validation-2026-10-02.json', 'answers':180, 'method':followup['method']},
        {'report':'references/validation-1.2.4.json', 'instruction_version':'1.2.4', 'answers':72, 'method':previous['method']}
      ]}
    (output / 'beforeword_release.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return path

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    print(build(args.output))
