# beforeword · 1.2.2

RU

Язык инструкции в этом архиве: EN. Установи одну языковую редакцию; одинаковое имя не предназначено для двух параллельных установок. Язык ответа можно задать в запросе.

Навык сохраняет исходный текст, отделяет добавленное прочтением и применяет ту же границу к собственному ответу. Он вызывается для задачи и не меняет все разговоры аккаунта. Для более широкого действия задавай область явно: «Применяй beforeword в этом разговоре». Для разового разбора: «Примени beforeword к фразе „Я понимаю“». Просьба «Отключи режим beforeword для следующих ответов» меняет запрос; доступность установленного навыка регулируется настройками приложения.

После подключения начни новый разговор и выполни пример. Сохрани ввод и ответ: наличие названия beforeword само по себе не показывает качество разбора. При проблеме запиши приложение, его версию, способ установки и полный текст ошибки. Пакет содержит только инструкции и файлы настройки, без сервера, ключей, фоновых действий и телеметрии.

EN

Instruction language in this archive: EN. Install one language edition; the shared name is not intended for two parallel installations. Request any response language explicitly.

The skill preserves the supplied text, separates added readings, and applies the same boundary to its own response. It is invoked for a task and does not change every conversation in an account. To request broader scope, say “Apply beforeword in this conversation.” For one task: “Apply beforeword to the phrase ‘I understand.’” The request “Turn off beforeword mode for subsequent replies” changes the requested scope; application settings control whether the installed skill remains available.

After setup, start a new conversation and try the example. Keep the input and output: the name beforeword appearing in a response does not establish the quality of its analysis. For troubleshooting, record the app, version, installation method, and complete error. The package contains only instructions and configuration files, with no server, keys, background actions, or telemetry.

## Claude / Cowork / Claude Code

RU

Claude и Cowork: `Customize → Plugins → Add → Upload plugin`, затем выбери этот ZIP. Манифест находится в `.claude-plugin/plugin.json` у корня архива. Не загружай вместо него ZIP локального каталога OpenAI. Доступность загрузки может зависеть от аккаунта и настроек организации.

Claude Code: распакуй архив в папку `beforeword`; из её родительской папки проверь структуру командой `claude plugin validate ./beforeword` и запусти новую сессию: `claude --plugin-dir ./beforeword`. Явный вызов в Code: `/beforeword:read`. В чате можно попросить применить beforeword по имени.

Для окончания временной сессии Code выйди из неё и начни следующую без `--plugin-dir`. Для установленного через интерфейс плагина используй его элементы отключения/удаления в Customize → Plugins. Перед обновлением сохрани свои изменения, замени архив или локальную папку новой редакцией и используй новую сессию; не держи две языковые копии с одинаковым именем.

EN

Claude and Cowork: choose `Customize → Plugins → Add → Upload plugin` and select this ZIP. Its manifest is at `.claude-plugin/plugin.json` from the archive root. Do not upload the OpenAI local-marketplace ZIP in its place. Account or organization settings may affect upload availability.

Claude Code: extract the archive into `beforeword`; from its parent folder, check the structure with `claude plugin validate ./beforeword`, then start a new session with `claude --plugin-dir ./beforeword`. Explicit Code invocation: `/beforeword:read`. In chat, request beforeword by name.

To end temporary Code loading, exit that session and start the next one without `--plugin-dir`. For an interface-installed plugin, use its disable/remove controls in Customize → Plugins. Before updating, retain your edits, replace the archive or local folder with the new edition, and use a new session; do not maintain two language copies under the same name.

Plugin packaging and loading: https://claude.com/docs/plugins/build
